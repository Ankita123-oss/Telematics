package com.assetTelematics.vehicle.feature_vehicle.di

import com.assetTelematics.vehicle.feature_vehicle.data.repository.VehicleApiService
import com.assetTelematics.vehicle.feature_vehicle.data.repository.VehicleRepositoryImpl
import com.assetTelematics.vehicle.feature_vehicle.domain.repository.VehicleRepository
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import retrofit2.Retrofit

@Module
@InstallIn(SingletonComponent::class)
object VehicleModule {

    @Provides
    fun providesVehicleApiService(retrofit: Retrofit): VehicleApiService {
        return retrofit.create(VehicleApiService::class.java)
    }

    @Provides
    fun providesVehicleRepository(vehicleApiService: VehicleApiService) : VehicleRepository {
        return VehicleRepositoryImpl(vehicleApiService)
    }

}