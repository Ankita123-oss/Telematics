package com.assetTelematics.vehicle.feature_vehicle.presentation

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.wrapContentSize
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.Button
import androidx.compose.material.ButtonDefaults
import androidx.compose.material.Card
import androidx.compose.material.CircularProgressIndicator
import androidx.compose.material.DropdownMenuItem
import androidx.compose.material.ExperimentalMaterialApi
import androidx.compose.material.Icon
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TextField
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.layout
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.navigation.NavHostController
import com.assetTelematics.vehicle.R
import com.google.accompanist.systemuicontroller.rememberSystemUiController

@OptIn(ExperimentalMaterial3Api::class, ExperimentalMaterialApi::class)
@Composable
fun VehicleDetailsComposable(
    vehicleDetailsViewmodel: VehicleDetailsViewmodel = hiltViewModel(),
) {
    val systemUiController = rememberSystemUiController()

    systemUiController.setStatusBarColor(
        color = Color.Red,
        darkIcons = false
    )

    Box(modifier = Modifier.fillMaxSize()) {
        Scaffold(
            topBar = {
                TopAppBar(title = {
                    Text(
                        text = stringResource(R.string.add_vehicle),
                        fontWeight = FontWeight.Bold
                    )
                }, navigationIcon = {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "ArrowBack"
                    )
                },
                    actions = {
                        IconButton(onClick = {  }) {
                            Icon(
                                imageVector = Icons.Filled.Refresh,
                                contentDescription = "Refresh"
                            )
                        }
                    })
            },

            ) { innerPadding ->

            val isNetworkAvailable = vehicleDetailsViewmodel.isNetworkAvailable.value

            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .background(Color(0xfff8f8f8))
            ) {
                if (isNetworkAvailable) {
                    BoxWithConstraints {
                        val parentConstraints = this.constraints

                        Column(
                            Modifier
                                .padding(13.dp)
                                .verticalScroll(rememberScrollState())
                                .background(Color(0xfff8f8f8)),
                        ) {
                            Text(text = stringResource(R.string.imei), fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.size(5.dp))

                            OutlinedTextField(modifier = Modifier.fillMaxWidth(),
                                value = vehicleDetailsViewmodel.vehicleIMEI.value,
                                onValueChange = {
                                    vehicleDetailsViewmodel.updateImeiText(it)
                                },
                                keyboardOptions = KeyboardOptions(
                                    keyboardType = KeyboardType.Number,
                                    imeAction = ImeAction.Next
                                ),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedTextColor = Color.Black, unfocusedTextColor = Color.Black
                                ),
                                trailingIcon = {
                                    IconButton(onClick = {
                                        vehicleDetailsViewmodel.scanQRCode()
                                    }) {
                                        Image(
                                            modifier = Modifier.size(28.dp),
                                            painter = painterResource(id = R.drawable.qrcode),
                                            contentDescription = "",
                                        )
                                    }
                                })

                            Spacer(modifier = Modifier.size(5.dp))

                            Text(
                                text = stringResource(R.string.vehicle_details),
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.size(5.dp))

                            var tagName by remember {
                                mutableStateOf("")
                            }

                            var registerNumber by remember {
                                mutableStateOf("")
                            }

                            OutlinedTextField(
                                modifier = Modifier.fillMaxWidth(),
                                value = tagName,
                                onValueChange = {
                                    tagName = it
                                },
                                keyboardOptions = KeyboardOptions(
                                    keyboardType = KeyboardType.Text,
                                    imeAction = ImeAction.Next
                                ),
                                placeholder = { Text(text = stringResource(R.string.tag_name)) },
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedTextColor = Color.Black, unfocusedTextColor = Color.Black
                                )
                            )
                            Spacer(modifier = Modifier.size(10.dp))
                            OutlinedTextField(
                                modifier = Modifier.fillMaxWidth(),
                                value = registerNumber,
                                onValueChange = {
                                    registerNumber = it
                                },
                                keyboardOptions = KeyboardOptions(
                                    keyboardType = KeyboardType.Text,
                                    imeAction = ImeAction.Done
                                ),
                                placeholder = { Text(text = stringResource(R.string.registration_number)) },
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedTextColor = Color.Black, unfocusedTextColor = Color.Black
                                )
                            )
                            Spacer(modifier = Modifier.size(5.dp))
                            if (vehicleDetailsViewmodel.mutableVehicleType.isNotEmpty()) {
                                Text(
                                    text = stringResource(R.string.vehicle_type),
                                    fontWeight = FontWeight.Bold
                                )

                                Row(modifier = Modifier.fillMaxWidth()) {

                                    Row(Modifier.weight(0.85f)) {
                                        LazyVerticalGrid(
                                            modifier = Modifier.layout { measurable, constraints ->
                                                val placeable = measurable.measure(
                                                    constraints.copy(maxHeight = parentConstraints.maxHeight)
                                                )

                                                layout(placeable.width, placeable.height) {
                                                    placeable.placeRelative(0, 0)
                                                }
                                            }, columns = GridCells.Fixed(3)
                                        ) {
                                            items(vehicleDetailsViewmodel.mutableVehicleType.size) { index ->
                                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                                    Image(
                                                        modifier = Modifier.size(35.dp),
                                                        painter = painterResource(id = R.drawable.truck_image),
                                                        contentDescription = ""
                                                    )
                                                    Spacer(modifier = Modifier.size(7.dp))
                                                    Text(
                                                        text = vehicleDetailsViewmodel.mutableVehicleType[index],
                                                        fontSize = 12.sp,
                                                        fontWeight = FontWeight.Bold
                                                    )
                                                }

                                            }
                                        }
                                    }

                                    Row(Modifier.weight(0.15f)) {
                                        var isExpanded by remember {
                                            mutableStateOf(false)
                                        }
                                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                            Card(
                                                modifier = Modifier.size(40.dp),
                                                backgroundColor = Color.Red,
                                                shape = RoundedCornerShape(size = 10.dp),
                                                onClick = {

                                                }
                                            ) {
                                                if (isExpanded) {
                                                    IconButton(onClick = {
                                                        isExpanded = isExpanded.not()
                                                        vehicleDetailsViewmodel.expandTheVehicles(
                                                            isExpanded
                                                        )
                                                    }) {
                                                        Icon(
                                                            painter = painterResource(id = R.drawable.remove_24px),
                                                            tint = Color.White,
                                                            contentDescription = "Less"
                                                        )
                                                    }

                                                } else {
                                                    IconButton(onClick = {
                                                        isExpanded = isExpanded.not()
                                                        vehicleDetailsViewmodel.expandTheVehicles(
                                                            isExpanded
                                                        )
                                                    }) {
                                                        Icon(
                                                            imageVector = Icons.Filled.Add,
                                                            tint = Color.White,
                                                            contentDescription = "More"
                                                        )
                                                    }
                                                }

                                            }
                                            Spacer(modifier = Modifier.height(7.dp))
                                            Text(
                                                text = if (isExpanded) stringResource(R.string.less) else stringResource(
                                                    R.string.more
                                                ),
                                                fontSize = 12.sp,
                                                textAlign = TextAlign.Center,
                                                fontWeight = FontWeight.Bold
                                            )

                                        }
                                    }
                                }
                            }
                            Spacer(modifier = Modifier.size(10.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                DropdownSelector(
                                    modifier = Modifier.weight(1f),
                                    options = vehicleDetailsViewmodel.vehicleModel.value.vehicleMake
                                        ?: listOf(),
                                    selectedOption = vehicleDetailsViewmodel.vehicleMaker.value,
                                    onOptionSelected = {
                                        vehicleDetailsViewmodel.updateVehicleMaker(it)
                                    },
                                )
                                Spacer(modifier = Modifier.size(10.dp))

                                DropdownSelector(
                                    modifier = Modifier.weight(1f),
                                    options = vehicleDetailsViewmodel.vehicleNamesList,
                                    selectedOption = vehicleDetailsViewmodel.vehicleName.value,
                                    onOptionSelected = {
                                        vehicleDetailsViewmodel.updateVehicleName(it)
                                    },
                                )

                            }
                            Spacer(modifier = Modifier.size(10.dp))


                            DropdownSelector(
                                options = vehicleDetailsViewmodel.vehicleModel.value.manufactureYear
                                    ?: listOf(),
                                selectedOption = vehicleDetailsViewmodel.vehicleManufactureYear.value,
                                onOptionSelected = {
                                    vehicleDetailsViewmodel.updateVehicleManufactureYear(it)
                                },
                            )
                            Spacer(modifier = Modifier.size(10.dp))

                            DropdownSelector(
                                options = vehicleDetailsViewmodel.vehicleModel.value.fuelType
                                    ?: listOf(),
                                selectedOption = vehicleDetailsViewmodel.vehicleFuelType.value,
                                onOptionSelected = {
                                    vehicleDetailsViewmodel.updateVehicleFuelType(it)
                                },
                            )
                            Spacer(modifier = Modifier.size(10.dp))

                            DropdownSelector(
                                options = vehicleDetailsViewmodel.vehicleModel.value.vehicleCapacity
                                    ?: listOf(),
                                selectedOption = vehicleDetailsViewmodel.vehicleCapacity.value,
                                onOptionSelected = {
                                    vehicleDetailsViewmodel.updateVehicleCapacity(it)
                                },
                            )
                            Spacer(modifier = Modifier.size(10.dp))

                            val context = LocalContext.current
                            var selectedOption by remember { mutableStateOf(context.getString(R.string.own)) }
                            Text(
                                text = stringResource(R.string.ownership),
                                fontWeight = FontWeight.Bold
                            )
                            Row {
                                Row(
                                    modifier = Modifier.clickable {
                                        selectedOption = context.getString(R.string.own)
                                    },
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    RadioButton(
                                        selected = selectedOption == stringResource(R.string.own),
                                        onClick = {
                                            selectedOption = context.getString(R.string.own)
                                        },
                                        colors = RadioButtonDefaults.colors(selectedColor = Color.Red)
                                    )
                                    Text(text = stringResource(R.string.own))
                                }
                                Row(
                                    modifier = Modifier.clickable {
                                        selectedOption = context.getString(R.string.contractor)
                                    },
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    RadioButton(
                                        selected = selectedOption == stringResource(R.string.contractor),
                                        onClick = {
                                            selectedOption = context.getString(R.string.contractor)
                                        },
                                        colors = RadioButtonDefaults.colors(selectedColor = Color.Red)
                                    )
                                    Text(text = stringResource(R.string.contractor))
                                }
                            }
                            Spacer(modifier = Modifier.size(10.dp))
                            DropdownSelector(
                                options = vehicleDetailsViewmodel.vehicleOwnershipList,
                                selectedOption = vehicleDetailsViewmodel.vehicleOwnershipList.first(),
                                onOptionSelected = {

                                },
                            )
                            Spacer(modifier = Modifier.size(90.dp))
                            Button(
                                modifier = Modifier.fillMaxWidth(),
                                onClick = { },
                                colors = ButtonDefaults.buttonColors(backgroundColor = Color.Red)
                            ) {
                                Text(text = stringResource(R.string.add), color = Color.White)
                            }
                        }
                    }
                } else {
                    NoNetworkComposable(onRetryClick = {
                        vehicleDetailsViewmodel.updateTheNetworkState()
                    })
                }
            }
        }
        if (vehicleDetailsViewmodel.vehicleApiState.value.isLoading) {
            Box(
                modifier = Modifier.fillMaxSize()
            ) {
                CircularProgressIndicator(modifier = Modifier.align(Alignment.Center))
            }
        }
    }
}

@Composable
fun DropdownSelector(
    modifier: Modifier = Modifier,
    options: List<String>,
    selectedOption: String,
    onOptionSelected: (String) -> Unit,
) {
    val expanded = remember { mutableStateOf(false) }

    Column(modifier = modifier) {
        OutlinedTextField(
            modifier = Modifier
                .fillMaxWidth()
                .clickable {
                    expanded.value = true
                },
            value = selectedOption,
            onValueChange = {},
            readOnly = true,
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = Color.Black, unfocusedTextColor = Color.Black
            ),
            trailingIcon = {
                IconButton(onClick = { expanded.value = true }) {
                    Text("▼")
                }
            })
        DropdownMenu(
            expanded = expanded.value,
            onDismissRequest = { expanded.value = false },
            modifier = Modifier.wrapContentSize()
        ) {
            options.forEach { option ->
                DropdownMenuItem(onClick = {
                    onOptionSelected(option)
                    expanded.value = false
                }) {
                    Text(text = option)
                }
            }
        }
    }
}

@Composable
fun NoNetworkComposable(onRetryClick: () -> Unit) {
    Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.Center) {
        TextButton(onClick = onRetryClick, content = {
            Text(text = stringResource(R.string.no_network_available_please_check_and_try_again))
        })
    }
}