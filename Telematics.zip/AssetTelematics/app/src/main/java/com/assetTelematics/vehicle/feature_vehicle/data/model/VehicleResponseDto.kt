package com.assetTelematics.vehicle.feature_vehicle.data.model

import com.assetTelematics.vehicle.feature_vehicle.domain.model.VehicleModel

data class VehicleResponseDto(
    val fuel_type: List<FuelType?>? = null,
    val manufacture_year: List<ManufactureYear?>? = null,
    val message: String? = null,
    val status: Int? = null,
    val vehicle_capacity: List<VehicleCapacity?>? = null,
    val vehicle_make: List<VehicleMake?>? = null,
    val vehicle_type: List<VehicleType?>? = null
) {
    fun toVehicleResponseModel(): VehicleModel {
        return VehicleModel(
            fuelType = fuel_type?.map { it?.text.orEmpty()  },
            manufactureYear = manufacture_year?.map { it?.text.orEmpty() },
            vehicleCapacity = vehicle_capacity?.map { it?.text.orEmpty() },
            vehicleMake = vehicle_make?.map { it?.text.orEmpty()  },
            vehicleType = vehicle_type?.map { it?.text.orEmpty()  }
        )
    }
}


data class FuelType(
    val images: String? = null,
    val text: String? = null,
    val value: Int? = null
)
data class ManufactureYear(
    val images: String? = null,
    val text: String? = null,
    val value: Int? = null
)
data class VehicleCapacity(
    val images: String? = null,
    val text: String? = null,
    val value: Int? = null
)

data class VehicleMake(
    val images: String? = null,
    val text: String? = null,
    val value: Int? = null
)
data class VehicleType(
    val images: String? = null,
    val text: String? = null,
    val value: Int? = null
)