package com.assetTelematics.vehicle.feature_vehicle.data.model

data class VehicleUpdateDto(
    val clientid: Int? = null,
    val enterprise_code: Int? = null,
    val mno: String? = null,
    val passcode: Int? = null
)
