package com.assetTelematics.vehicle.feature_vehicle.domain.repository

import com.assetTelematics.vehicle.core.Resource
import com.assetTelematics.vehicle.feature_vehicle.data.model.VehicleUpdateDto
import com.assetTelematics.vehicle.feature_vehicle.domain.model.VehicleModel
import kotlinx.coroutines.flow.Flow

interface VehicleRepository {

    fun getVehicleDetails(vehicleUpdateDto: VehicleUpdateDto): Flow<Resource<VehicleModel>>

}