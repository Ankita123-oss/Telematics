package com.assetTelematics.vehicle.feature_vehicle.presentation

import android.app.Application
import android.util.Log
import android.widget.Toast
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.snapshots.SnapshotStateList
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.assetTelematics.vehicle.R
import com.google.android.gms.common.moduleinstall.ModuleInstall
import com.google.android.gms.common.moduleinstall.ModuleInstallRequest
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.codescanner.GmsBarcodeScanner
import com.google.mlkit.vision.codescanner.GmsBarcodeScannerOptions
import com.google.mlkit.vision.codescanner.GmsBarcodeScanning
import com.assetTelematics.vehicle.core.Resource
import com.assetTelematics.vehicle.core.utils.isNetworkAvailable
import com.assetTelematics.vehicle.feature_vehicle.domain.model.VehicleModel
import com.assetTelematics.vehicle.feature_vehicle.domain.usecases.GetVehicleDetailsUseCase
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class VehicleDetailsViewmodel @Inject constructor(
    private val application: Application,
    private val getVehicleDetailsUseCase: GetVehicleDetailsUseCase,
) : AndroidViewModel(application) {

    private val _vehicleApiState = mutableStateOf(VehicleState())
    val vehicleApiState: State<VehicleState> = _vehicleApiState

    private val _vehicleModel: MutableState<VehicleModel> = mutableStateOf(VehicleModel())
    val vehicleModel: State<VehicleModel> = _vehicleModel

    private val _vehicleIMEI: MutableState<String> = mutableStateOf("")
    val vehicleIMEI: State<String> = _vehicleIMEI

    private val _vehicleMaker: MutableState<String> = mutableStateOf("")
    val vehicleMaker: State<String> = _vehicleMaker

    private val _vehicleName: MutableState<String> = mutableStateOf("")
    val vehicleName: State<String> = _vehicleName

    private val _vehicleManufactureYear: MutableState<String> = mutableStateOf("")
    val vehicleManufactureYear: State<String> = _vehicleManufactureYear

    private val _vehicleFuelType: MutableState<String> = mutableStateOf("")
    val vehicleFuelType: State<String> = _vehicleFuelType

    val mutableVehicleType: SnapshotStateList<String> = mutableStateListOf()

    private var vehicleTypeList = listOf<String>()

    private val _vehicleCapacity: MutableState<String> = mutableStateOf("")
    val vehicleCapacity: State<String> = _vehicleCapacity


    private val _isNetworkAvailable: MutableState<Boolean> = mutableStateOf(true)
    val isNetworkAvailable: State<Boolean> = _isNetworkAvailable


    private var isScannerInstalled: Boolean = false
    private lateinit var scanner: GmsBarcodeScanner
    val vehicleNamesList = listOf(
        application.getString(R.string.baleno),
        application.getString(R.string.tiago),
        application.getString(R.string.harrier), application.getString(R.string.creta),
        application.getString(
            R.string.alto
        )
    )

    val vehicleOwnershipList = listOf(
        application.getString(R.string.driver), application.getString(R.string.owner)
    )

    init {
        updateTheNetworkState()
        installGoogleScanner()
    }

    private fun getVehicleMasterData() {
        viewModelScope.launch {
            getVehicleDetailsUseCase.invoke().onEach { result ->
                when (result) {
                    is Resource.Loading -> {
                        _vehicleApiState.value = VehicleState(isLoading = true)

                    }
                    is Resource.Success -> {
                        _vehicleApiState.value =
                            VehicleState(isLoading = false)
                        result.data!!.run {
                            _vehicleModel.value = this
                            _vehicleMaker.value = vehicleMake?.firstOrNull().orEmpty()
                            _vehicleName.value = vehicleNamesList.first()
                            _vehicleManufactureYear.value = manufactureYear?.firstOrNull().orEmpty()
                            _vehicleFuelType.value = fuelType?.firstOrNull().orEmpty()
                            _vehicleCapacity.value = vehicleCapacity?.firstOrNull().orEmpty()
                            vehicleTypeList = vehicleType ?: listOf()
                            mutableVehicleType.clear()
                            mutableVehicleType.addAll(vehicleTypeList.take(3))
                        }
                    }

                    is Resource.Error -> {
                        _vehicleApiState.value =
                            VehicleState(isLoading = false, error = result.message)
                    }
                }
            }.launchIn(this)
        }
    }

    fun updateVehicleMaker(vehicleMakeModel: String) {
        _vehicleMaker.value = vehicleMakeModel
    }

    fun updateVehicleName(vehicleName: String) {
        _vehicleName.value = vehicleName
    }

    fun updateVehicleManufactureYear(vehicleManufactureYear: String) {
        _vehicleManufactureYear.value = vehicleManufactureYear
    }

    fun updateVehicleFuelType(vehicleFuelType: String) {
        _vehicleFuelType.value = vehicleFuelType
    }

    fun updateVehicleCapacity(vehicleCapacity: String) {
        _vehicleCapacity.value = vehicleCapacity
    }

    private fun installGoogleScanner() {
        val moduleInstall = ModuleInstall.getClient(application)
        val moduleInstallRequest = ModuleInstallRequest.newBuilder()
            .addApi(GmsBarcodeScanning.getClient(application))
            .build()

        moduleInstall.installModules(moduleInstallRequest).addOnSuccessListener {
            isScannerInstalled = true
        }.addOnFailureListener {
            isScannerInstalled = false
            Toast.makeText(application, it.message, Toast.LENGTH_SHORT).show()
        }

        val options = initializeGoogleScanner()
        scanner = GmsBarcodeScanning.getClient(application, options)
    }

    private fun initializeGoogleScanner(): GmsBarcodeScannerOptions {
        return GmsBarcodeScannerOptions.Builder().setBarcodeFormats(Barcode.FORMAT_QR_CODE)
            .enableAutoZoom().build()
    }

    fun scanQRCode() {
        if (isScannerInstalled) {
            startScanning()
        } else {
            Toast.makeText(
                application,
                application.getString(R.string.please_try_again), Toast.LENGTH_SHORT
            ).show()
        }
    }

    private fun startScanning() {
        scanner.startScan().addOnSuccessListener {
            val result = it.rawValue
            _vehicleIMEI.value = result.orEmpty()
        }.addOnCanceledListener {
        }.addOnFailureListener {
            Toast.makeText(application, it.message, Toast.LENGTH_SHORT).show()
        }
    }

    fun updateTheNetworkState() {
        val isOnline = application.isNetworkAvailable()
        _isNetworkAvailable.value = isOnline
        if (isOnline) {
            getVehicleMasterData()
        }
    }

    fun updateImeiText(imei: String) {
        val imeliValue = imei.replace("[^0-9]".toRegex(), "")
        if (imeliValue.count() in 0..15) {
            _vehicleIMEI.value = imeliValue
        }
    }

    fun expandTheVehicles(expanded: Boolean) {
        if (expanded) {
            mutableVehicleType.clear()
            mutableVehicleType.addAll(vehicleTypeList)
        } else {
            mutableVehicleType.clear()
            mutableVehicleType.addAll(vehicleTypeList.take(3))
        }
    }
}