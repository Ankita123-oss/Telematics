package com.assetTelematics.vehicle.feature_vehicle.domain.usecases

import com.assetTelematics.vehicle.core.Resource
import com.assetTelematics.vehicle.feature_vehicle.data.model.VehicleUpdateDto
import com.assetTelematics.vehicle.feature_vehicle.domain.repository.VehicleRepository
import com.assetTelematics.vehicle.feature_vehicle.domain.model.VehicleModel
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject

class GetVehicleDetailsUseCase @Inject constructor(private val vehicleRepository: VehicleRepository) {

    operator fun invoke(): Flow<Resource<VehicleModel>> {
        val vehicleUpdateDto = VehicleUpdateDto(
           clientid = 11,
            enterprise_code = 1007,
            mno = "9889897789",
            passcode = 3476
        )
        return vehicleRepository.getVehicleDetails(vehicleUpdateDto)
    }
}