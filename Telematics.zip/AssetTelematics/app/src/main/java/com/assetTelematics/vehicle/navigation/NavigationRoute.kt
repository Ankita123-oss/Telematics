package com.assetTelematics.vehicle.navigation

sealed class NavigationRoute(val rootName: String) {
    data object VehicleScreen: NavigationRoute("VehicleScreen")
}