package com.assetTelematics.vehicle.feature_vehicle.presentation

import com.assetTelematics.vehicle.feature_vehicle.domain.model.VehicleModel

data class VehicleState(
    val isLoading: Boolean = false,
    val error: String? = null)