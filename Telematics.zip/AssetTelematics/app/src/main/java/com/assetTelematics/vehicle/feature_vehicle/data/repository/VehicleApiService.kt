package com.assetTelematics.vehicle.feature_vehicle.data.repository

import com.assetTelematics.vehicle.feature_vehicle.data.model.VehicleResponseDto
import com.assetTelematics.vehicle.feature_vehicle.data.model.VehicleUpdateDto
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.POST

interface VehicleApiService {

    @POST("configure/v1/task")
    suspend fun getVehicleDetails(@Body vehicleUpdateDto: VehicleUpdateDto): Response<VehicleResponseDto>

}