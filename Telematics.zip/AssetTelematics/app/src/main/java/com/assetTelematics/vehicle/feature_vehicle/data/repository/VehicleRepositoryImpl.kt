package com.assetTelematics.vehicle.feature_vehicle.data.repository

import android.util.Log
import com.assetTelematics.vehicle.core.Resource
import com.assetTelematics.vehicle.feature_vehicle.data.model.VehicleUpdateDto
import com.assetTelematics.vehicle.feature_vehicle.domain.repository.VehicleRepository
import com.assetTelematics.vehicle.feature_vehicle.domain.model.VehicleModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import retrofit2.HttpException
import java.io.IOException
import java.net.SocketTimeoutException
import javax.inject.Inject

class VehicleRepositoryImpl @Inject constructor(private val vehicleApiService: VehicleApiService) :
    VehicleRepository {
    override fun getVehicleDetails(vehicleUpdateDto: VehicleUpdateDto): Flow<Resource<VehicleModel>> = flow {
        emit(Resource.Loading())
        try {
            val response = vehicleApiService.getVehicleDetails(vehicleUpdateDto)
            Log.e("response","$response")
            if (response.isSuccessful) {

                if (response.body() != null) {
                    emit(
                        Resource.Success(response.body()!!.toVehicleResponseModel()))
                } else {
                    emit(Resource.Error(response.errorBody()?.string().orEmpty(), null))
                }

            } else {
                emit(Resource.Error(response.errorBody()?.string().orEmpty(), null))
            }
        } catch (e: SocketTimeoutException) {
            emit(Resource.Error("Timeout exception occurred"))
        } catch (e: HttpException) {
            emit(Resource.Error("API Exception"))
        } catch (e: IOException) {
            emit(Resource.Error("No Internet"))
        } catch (e: Exception) {
            emit(Resource.Error("Unknown error"))
        }
    }

}