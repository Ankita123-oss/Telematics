package com.assetTelematics.vehicle.feature_vehicle.domain.model

data class VehicleModel(
    val fuelType: List<String>? = null,
    val manufactureYear: List<String>? = null,
    val vehicleCapacity: List<String>? = null,
    val vehicleMake: List<String>? = null,
    val vehicleType: List<String>? = null
)
